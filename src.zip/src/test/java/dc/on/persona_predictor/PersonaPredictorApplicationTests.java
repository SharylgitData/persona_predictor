//package dc.on.persona_predictor;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class PersonaPredictorApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
