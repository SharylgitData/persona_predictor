package dc.on.persona_predictor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonaPredictorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonaPredictorApplication.class, args);
	}

}
