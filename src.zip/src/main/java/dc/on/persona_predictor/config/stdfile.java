package dc.on.persona_predictor.config;


import java.io.*;


public class stdfile {

    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in) );
        //StringTokenizer st = new StringTokenizer(br.readLine())
        int n = Integer.parseInt(br.readLine());
        String chain="";
        for(int i=0;i<n;i++){
            chain +=  "Hello Morgan" ;
        }
        System.out.print(chain);
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
    }
}